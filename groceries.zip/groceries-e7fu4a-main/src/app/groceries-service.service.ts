import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GroceriesServiceService {

  items= [
    {
      name: "milk",
      quantity: 2
    },
    {
      name: "bread",
      quantity: 1
    },
    {
      name: "eggs",
      quantity: 2
    },
    {
      name: "sugar",
      quantity: 3
    },
  ];

  constructor() { }

  getItems() {
    return this.items;
  }

  presentRemoveItem(index: any) {
    this.items.splice(index, 1);
  }

  addItem(item: any) {
    this.items.push(item);
  }

  presentEditItem(item: any, index: any) {
    this.items[index] = item;
  }

}
